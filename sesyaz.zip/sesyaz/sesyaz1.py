import speech_recognition as sr
import sounddevice as sd
import wave
import webbrowser
import pyautogui


def ses_kaydi_yap(dosya_adi, sure=5, ornek_rate=44100):
    # Ses kaydı için parametreleri belirle
    kayit_suresi = sure  # saniye cinsinden
    ornekleme_orani = ornek_rate  # Hz cinsinden

    # Ses kaydını başlat
    ses_kaydi = sd.rec(int(ornekleme_orani * kayit_suresi), samplerate=ornekleme_orani, channels=2, dtype='int16')
    sd.wait()

    # Ses kaydını dosyaya yaz
    with wave.open(dosya_adi, 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(ornekleme_orani)
        wf.writeframes(ses_kaydi.tobytes())

    print("Ses kaydı '{}' dosyasına kaydedildi.".format(dosya_adi))

# Ses kaydı yapmak için dosya adını ve kayıt süresini belirtin
dosya_adi = "ses_kaydi.wav"
kayit_suresi = 5 # saniye cinsinden

# Ses kaydını başlat
ses_kaydi_yap(dosya_adi, kayit_suresi)

def sesi_metne_cevir(audio_path):
    recognizer = sr.Recognizer()

    with sr.AudioFile(audio_path) as source:
        audio = recognizer.record(source)

    try:
        metin = recognizer.recognize_google(audio, language="tr-TR")
        print("Metin: {}".format(metin))
    except sr.UnknownValueError:
        print("Ses algılanamadı")
    except sr.RequestError as e:
        print("Google Speech Recognition API'ye erişilemiyor; {0}".format(e))
    try:
        # Ses dosyasını metne çevirin
        text = recognizer.recognize_google(audio, language="tr-TR")
        print("Söylenen metin: {}".format(text))
        if text == "YouTube'u aç":
            webbrowser.open("https://www.youtube.com/")
        elif text == "roblox'u aç":
            webbrowser.open("https://www.roblox.com/home")
            
    except sr.UnknownValueError:
        print("Anlaşılamayan ses")
    except sr.RequestError as e:
        print("Ses tanıma servisine ulaşılamıyor; {0}".format(e))

# Sesi metne çevirmek için dosya yolu belirtin
ses_dosya_yolu = "ses_kaydi.wav"
sesi_metne_cevir(ses_dosya_yolu)
