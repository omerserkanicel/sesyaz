import sounddevice as sd
import wave

def ses_kaydi_yap(dosya_adi, sure=5, ornek_rate=44100):
    # Ses kaydı için parametreleri belirle
    kayit_suresi = sure  # saniye cinsinden
    ornekleme_orani = ornek_rate  # Hz cinsinden

    # Ses kaydını başlat
    ses_kaydi = sd.rec(int(ornekleme_orani * kayit_suresi), samplerate=ornekleme_orani, channels=2, dtype='int16')
    sd.wait()

    # Ses kaydını dosyaya yaz
    with wave.open(dosya_adi, 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(ornekleme_orani)
        wf.writeframes(ses_kaydi.tobytes())

    print("Ses kaydı '{}' dosyasına kaydedildi.".format(dosya_adi))

# Ses kaydı yapmak için dosya adını ve kayıt süresini belirtin
dosya_adi = "ses_kaydi.wav"
kayit_suresi = 5  # saniye cinsinden

# Ses kaydını başlat
ses_kaydi_yap(dosya_adi, kayit_suresi)
