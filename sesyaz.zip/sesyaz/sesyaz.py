import speech_recognition as sr
import webbrowser
import pyautogui
# SpeechRecognition nesnesi oluşturun


# SpeechRecognition nesnesi oluşturun
recognizer = sr.Recognizer()

# Ses kaynağını belirtin (örneğin, mikrofon veya ses dosyası)
with sr.Microphone() as source:
    print("Bir şeyler söyleyin...")
    audio = recognizer.listen(source)

    try:
        # Ses dosyasını metne çevirin
        text = recognizer.recognize_google(audio, language="tr-TR")
        print("Söylenen metin: {}".format(text))
        if text == "YouTube'u aç":
            webbrowser.open("https://www.youtube.com/")
        elif text == "roblox'u aç":
            webbrowser.open("https://www.roblox.com/home")
            
    except sr.UnknownValueError:
        print("Anlaşılamayan ses")
    except sr.RequestError as e:
        print("Ses tanıma servisine ulaşılamıyor; {0}".format(e))
