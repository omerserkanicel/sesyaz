import discord
from discord.ext import commands
import sounddevice as sd
import wave
import speech_recognition as sr
import webbrowser 

intents = discord.Intents.default()

# Mesajları okuma ayrıcalığını etkinleştirelim

intents.message_content = True

# istemci (client) değişkeniyle bir bot oluşturalım ve ayrıcalıkları ona aktaralım

client = discord.Client(intents=intents)
# Discord botunu oluşturun
client = commands.Bot(intents=intents,command_prefix="/")

@client.event
async def on_ready():
    print(f'Bot olarak giriş yaptık: {client.user.name}')

@client.command(name='ses_kaydi')
async def ses_kaydi(ctx, dosya_adi="ses_kaydi.wav", sure=5, ornek_rate=44100):
    kayit_suresi = sure
    ornekleme_orani = ornek_rate

    # Ses kaydını başlat
    ses_kaydi = sd.rec(int(ornekleme_orani * kayit_suresi), samplerate=ornekleme_orani, channels=2, dtype='int16')
    sd.wait()

    # Ses kaydını dosyaya yaz
    with wave.open(dosya_adi, 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(ornekleme_orani)
        wf.writeframes(ses_kaydi.tobytes())

    await ctx.send(f"Ses kaydı '{dosya_adi}' dosyasına kaydedildi.")

@client.command(name='sesi_metne_cevir')
async def sesi_metne_cevir(ctx, audio_path="ses_kaydi.wav"):
    recognizer = sr.Recognizer()

    with sr.AudioFile(audio_path) as source:
        audio = recognizer.record(source)

    try:
        metin = recognizer.recognize_google(audio, language="tr-TR")
        print("Metin: {}".format(metin))
        await ctx.send(f"Metin: {metin}")

        if metin == "YouTube'u aç":
            await ctx.send("YouTube'u açıyorum!")
            webbrowser.open("https://www.youtube.com/")
        elif metin == "roblox'u aç":
            await ctx.send("Roblox'u açıyorum!")
            webbrowser.open("https://www.roblox.com/home")

    except sr.UnknownValueError:
        await ctx.send("Ses algılanamadı")
    except sr.RequestError as e:
        await ctx.send(f"Google Speech Recognition API'ye erişilemiyor; {e}")




client.run("MTE3NTQwNjE3MzI5MDIzODAwMg.GilGwT.IMtO1A9payP1rPXwy7p_cAFxldEVjIV3_UJcAw")  # TOKEN yerine botunuzun gerçek token'ını ekleyin
    
